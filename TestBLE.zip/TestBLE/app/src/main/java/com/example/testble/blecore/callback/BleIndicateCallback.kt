package com.example.testble.blecore.callback

import com.example.testble.blecore.callback.BleBaseCallback


/**
 * 订阅通知回调
 * Indicate方式
 *
 * @author Buhuiming
 * @date 2023年05月29日 08时47分
 */
open class BleIndicateCallback : BleBaseCallback() {

    private var indicateSuccess: (() -> Unit)? = null

    private var indicateFail: ((throwable: Throwable) -> Unit)? = null

    private var characteristicChanged: ((data: ByteArray) -> Unit)? = null

    fun onIndicateFail(value: ((throwable: Throwable) -> Unit)) {
        indicateFail = value
    }

    fun onIndicateSuccess(value: (() -> Unit)) {
        indicateSuccess = value
    }

    fun onCharacteristicChanged(value: ((data: ByteArray) -> Unit)) {
        characteristicChanged = value
    }

    open fun callIndicateFail(throwable: Throwable) {
        launchInMainThread {
            indicateFail?.invoke(throwable)
        }
    }

    open fun callIndicateSuccess() {
        launchInMainThread {
            indicateSuccess?.invoke()
        }
    }

    open fun callCharacteristicChanged(data: ByteArray) {
        //数据处理放在非主线程
        launchInIOThread {
            characteristicChanged?.invoke(data)
        }
    }
}