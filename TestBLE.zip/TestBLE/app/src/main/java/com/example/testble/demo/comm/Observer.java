package com.example.testble.demo.comm;


import com.example.testble.fastble.data.BleDevice;

public interface Observer {

    void disConnected(BleDevice bleDevice);
}
