package com.example.testble.clientserver;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;


import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.testble.R;
import com.example.testble.clientserver.ble.BleClientActivity;
import com.example.testble.clientserver.ble.BleServerActivity;
import com.example.testble.demo.MainActivity1;
import com.example.testble.demo3.bleclient.MainClientActivity;
import com.example.testble.demo3.bleserver.MainServerActivity;

import java.util.ArrayList;
import java.util.List;


public class MainActivity3 extends Activity {

    private static final String TAG = MainActivity3.class.getSimpleName();

    private static final int REQUEST_CODE_OPEN_GPS = 2;
    private static final int REQUEST_PERMISSION_CODE = 3;
    private static final int REQUEST_ENABLE_BLUETOOTH = 4;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Log.e(TAG,"SDK_INT="+Build.VERSION.SDK_INT);

        // 检查蓝牙开关
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            BaseApplication.toast("本机没有找到蓝牙硬件或驱动！", 0);
            finish();
            return;
        }

        // 检查是否支持BLE蓝牙
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            BaseApplication.toast("本机不支持低功耗蓝牙！", 0);
            finish();
            return;
        }

        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (!bluetoothAdapter.isEnabled()) {
            // 蓝牙未打开
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BLUETOOTH);
            BaseApplication.toast("请先打开蓝牙", 0);
            return;
        }

        //如果未打开位置服务，让用户去打开
        if(!isLocationEnable(MainActivity3.this)){
            Intent locationIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivityForResult(locationIntent, REQUEST_CODE_OPEN_GPS);
            BaseApplication.toast("请先打开定位", 0);
        }

        List<String> mPermissionList = new ArrayList<>();
        // Android 版本大于等于 12 时，申请新的蓝牙权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            mPermissionList.add(Manifest.permission.BLUETOOTH_SCAN);
            mPermissionList.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            mPermissionList.add(Manifest.permission.BLUETOOTH_CONNECT);
            //根据实际需要申请定位权限
            mPermissionList.add(Manifest.permission.ACCESS_COARSE_LOCATION);
            mPermissionList.add(Manifest.permission.ACCESS_FINE_LOCATION);
        } else {
            mPermissionList.add(Manifest.permission.ACCESS_FINE_LOCATION);
            mPermissionList.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        boolean hasPermission = false;
        for (int i = 0; i < mPermissionList.size(); i++) {
            int permissionCheck = ContextCompat.checkSelfPermission(this, mPermissionList.get(i));
            hasPermission = permissionCheck == PackageManager.PERMISSION_GRANTED;
        }
        if (hasPermission) {

        } else {
            ActivityCompat.requestPermissions(this, mPermissionList.toArray(new String[0]), REQUEST_PERMISSION_CODE);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_OPEN_GPS) {

        } else if (requestCode == REQUEST_ENABLE_BLUETOOTH) {

        }
    }

    @Override
    public final void onRequestPermissionsResult(int requestCode,
                                                 @NonNull String[] permissions,
                                                 @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION_CODE) {
            if (grantResults.length > 0) {
                for (int i = 0; i < grantResults.length; i++) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {

                    }
                }
            }
        }
    }

    private  boolean isLocationEnable(Context context) {
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        boolean networkProvider = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        boolean gpsProvider = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

        return networkProvider || gpsProvider;
    }

    public void bleClient(View view) {
        startActivity(new Intent(this, BleClientActivity.class));
    }

    public void bleServer(View view) {
        startActivity(new Intent(this, BleServerActivity.class));
    }

    public void bleClient2(View view) {
        startActivity(new Intent(this, MainClientActivity.class));
    }

    public void bleServer2(View view) {
        startActivity(new Intent(this, MainServerActivity.class));
    }

    public void bleDemo(View view) {
        startActivity(new Intent(this, MainActivity1.class));
    }
}
