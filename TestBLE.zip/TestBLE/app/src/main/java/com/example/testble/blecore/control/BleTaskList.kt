package com.example.testble.blecore.control

import java.util.*


/**
 * 存放操作任务
 *
 * @author Buhuiming
 * @date 2023年06月06日 10时41分
 */
internal class BleTaskList {

    private val taskIdList = Collections.synchronizedList(LinkedList<String>())

    private val list = Collections.synchronizedList(LinkedList<BleTask>())

    fun list(): MutableList<BleTask> = list

    fun add(element: BleTask) {
        taskIdList.add(element.taskId)
        list.add(element)
    }

    fun remove(element: BleTask?) {
        if (taskIdList.contains(element?.taskId)) {
            taskIdList.remove(element?.taskId)
        }
        list.remove(element)
    }

    fun iterator() = list.iterator()

    fun size() = list.size

    fun contains(task: BleTask?) = list.contains(task)

    fun clear() {
        list.clear()
        taskIdList.clear()
    }

    fun firstOrNull() = list.firstOrNull()

    fun containsTaskId(taskId: String) = taskIdList.contains(taskId)
}