package com.example.testble.clientserver.ble;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.os.Build;
import android.os.Bundle;

import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.testble.R;
import com.example.testble.clientserver.BaseApplication;
import com.example.testble.clientserver.util.CRC8;
import com.example.testble.clientserver.util.IntByteStringHexUtil;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.UUID;

/**
 * BLE客户端
 */
public class BleClientActivity extends Activity {

    private static final String TAG = BleClientActivity.class.getSimpleName();

    private EditText mWriteET;
    private TextView mTips;
    private ScrollView scrollView;
    private RecyclerView recyclerView;
    private Button btn_scan;
    private Button btn_clean_log;
    private Button btn_read;
    private Button btn_notify;
    private Button btn_write;
    private Button btn_write_cmd;
    private Button btn_write_long_cmd;


    private BleDevAdapter mBleDevAdapter;
    private BluetoothGatt mBluetoothGatt;
    private boolean isConnected = false;

    private static final int bleSize = 20;
    private static Queue<String> queue = new LinkedList<String>();

    private int count;

    // 与服务端连接的Callback
    public BluetoothGattCallback mBluetoothGattCallback = new BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            BluetoothDevice dev = gatt.getDevice();
            Log.i(TAG, String.format("onConnectionStateChange:%s,%s,%s,%s", dev.getName(), dev.getAddress(), status, newState));
            if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                isConnected = true;
                gatt.discoverServices(); //启动服务发现
            } else {
                isConnected = false;
                closeConn();
            }
            logTv(String.format(status == 0 ? (newState == 2 ? "与[%s]连接成功" : "与[%s]连接断开") : ("与[%s]连接出错,错误码:" + status), dev));
        }

        @SuppressLint("MissingPermission")
        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            Log.i(TAG, String.format("onServicesDiscovered:%s,%s,%s", gatt.getDevice().getName(), gatt.getDevice().getAddress(), status));
            if (status == BluetoothGatt.GATT_SUCCESS) { //BLE服务发现成功
                // 遍历获取BLE服务Services/Characteristics/Descriptors的全部UUID
                for (BluetoothGattService service : gatt.getServices()) {
                    StringBuilder allUUIDs = new StringBuilder("UUIDs={\nS=" + service.getUuid().toString());
                    for (BluetoothGattCharacteristic characteristic : service.getCharacteristics()) {
                        allUUIDs.append(",\nC=").append(characteristic.getUuid());
                        for (BluetoothGattDescriptor descriptor : characteristic.getDescriptors())
                            allUUIDs.append(",\nD=").append(descriptor.getUuid());
                    }
                    allUUIDs.append("}");
                    Log.i(TAG, "onServicesDiscovered:" + allUUIDs.toString());
                    logTv("发现服务" + allUUIDs);
                }
            }
        }

        @SuppressLint("MissingPermission")
        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            UUID uuid = characteristic.getUuid();
            String valueStr = new String(characteristic.getValue());
            Log.e(TAG, String.format("onCharacteristicRead:%s,%s,%s,%s,%s", gatt.getDevice().getName(), gatt.getDevice().getAddress(), uuid, valueStr, status));
            logTv("读取Characteristic[" + uuid + "]:\n" + valueStr);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            UUID uuid = characteristic.getUuid();
            String valueStr = new String(characteristic.getValue());
            Log.e(TAG, String.format("onCharacteristicWrite:%s,%s,%s,%s,%s", gatt.getDevice().getName(), gatt.getDevice().getAddress(), uuid, valueStr, status));
            logTv("写入Characteristic[" + uuid + "]:\n" + valueStr);

            if (queue.size() > 0) {
                bleNotifyDevice(Base64.decode(queue.poll(), Base64.NO_WRAP));
            }
        }

        @SuppressLint("MissingPermission")
        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            UUID uuid = characteristic.getUuid();
            String valueStr = new String(characteristic.getValue());
            Log.e(TAG, String.format("onCharacteristicChanged:%s,%s,%s,%s", gatt.getDevice().getName(), gatt.getDevice().getAddress(), uuid, valueStr));
            logTv("通知Characteristic[" + uuid + "]:\n" + valueStr);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            UUID uuid = descriptor.getUuid();
            String valueStr = Arrays.toString(descriptor.getValue());
            Log.i(TAG, String.format("onDescriptorRead:%s,%s,%s,%s,%s", gatt.getDevice().getName(), gatt.getDevice().getAddress(), uuid, valueStr, status));
            logTv("读取Descriptor[" + uuid + "]:\n" + valueStr);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            UUID uuid = descriptor.getUuid();
            String valueStr = Arrays.toString(descriptor.getValue());
            Log.e(TAG, String.format("onDescriptorWrite:%s,%s,%s,%s,%s", gatt.getDevice().getName(), gatt.getDevice().getAddress(), uuid, valueStr, status));
            logTv("写入Descriptor[" + uuid + "]:\n" + valueStr);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void onServiceChanged(@NonNull BluetoothGatt gatt) {
            Log.i(TAG, String.format("onServicesDiscovered:%s,%s", gatt.getDevice().getName(), gatt.getDevice().getAddress()));
        }
        @SuppressLint("MissingPermission")
        @Override
        public void onReliableWriteCompleted(BluetoothGatt gatt, int status) {
            Log.i(TAG, String.format("onServicesDiscovered:%s,%s,%s", gatt.getDevice().getName(), gatt.getDevice().getAddress(),status));
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bleclient);
        recyclerView = findViewById(R.id.rv_ble);
        mWriteET = findViewById(R.id.et_write);
        mTips = findViewById(R.id.tv_tips);
        scrollView = findViewById(R.id.sv);
        btn_scan = findViewById(R.id.btn_scan);
        btn_clean_log = findViewById(R.id.btn_clean_log);
        btn_read = findViewById(R.id.btn_read);
        btn_notify = findViewById(R.id.btn_notify);
        btn_write = findViewById(R.id.btn_write);
        btn_write_cmd =  findViewById(R.id.btn_write_cmd);
        btn_write_long_cmd = findViewById(R.id.btn_write_long_cmd);

        btn_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reScan();
            }
        });
        btn_clean_log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cleanLog();
            }
        });
        btn_read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                read();
            }
        });
        btn_notify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setNotify();
            }
        });
        btn_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                write();
            }
        });
        btn_write_cmd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                writeCmd();
            }
        });
        btn_write_long_cmd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                writeLongCmd();
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mBleDevAdapter = new BleDevAdapter(new BleDevAdapter.Listener() {

            @SuppressLint("MissingPermission")
            @Override
            public void onItemClick(BluetoothDevice dev) {
                closeConn();

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    mBluetoothGatt = dev.connectGatt(BleClientActivity.this, false, mBluetoothGattCallback, BluetoothDevice.TRANSPORT_LE);
                } else {
                    mBluetoothGatt = dev.connectGatt(BleClientActivity.this, false, mBluetoothGattCallback);
                }

                //autoConnect 这意味着 是否直接连接到远程设备（false）或在远程设备可用时立即自动连接（true）
                //以下方案还是无效
                //mBluetoothGatt = dev.connectGatt(BleClientActivity.this, true, mBluetoothGattCallback,TRANSPORT_LE); // 连接蓝牙设备
                //bluetoothDevice.connectGatt(MainActivity.this, true, gattCallback);总是连接失败，提示status返回133，用了各种方法都不行，
                // 后台一查才发现6.0及以上系统的手机要使用bluetoothDevice.connectGatt(MainActivity.this,true, gattCallback, TRANSPORT_LE)，
                // 其中TRANSPORT_LE参数是设置传输层模式。传输层模式有三种TRANSPORT_AUTO 、TRANSPORT_BREDR 和TRANSPORT_LE。
                // 如果不传默认TRANSPORT_AUTO，6.0系统及以上需要使用TRANSPORT_LE这种传输模式，
                // 具体为啥，我也不知道，我猜是因为Android6.0及以上系统重新定义了蓝牙BLE的传输模式必须使用TRANSPORT_LE这种方式吧。

                //发起蓝牙Gatt连接 BluetoothDevice.connectGatt(Context context, boolean autoConnect,
                //BluetoothGattCallback callback)，这里有一个参数autoConnect，如果为 true
                //的话，系统就会发起一个后台连接，等到系统发现了一个设备，就会自动连上，通常这个过程是非常慢的。为
                //false 的话，就会直接连接，通常会比较快。同样，BluetoothGatt.connect()只能发起一个后台连接，不是直
                //接连接,所以连接时设置autoConnect参数设置为false，如果想实现重连功能的话，自己去手动实现吧，实在不
                //想手动写

                logTv(String.format("与[%s]开始连接............", dev));
            }
        });
        recyclerView.setAdapter(mBleDevAdapter);
    }

    private void scrollToBottom(){
        if (null != scrollView){
            scrollView.fullScroll(View.FOCUS_DOWN);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        closeConn();
    }

    /**
     * 清理本地的BluetoothGatt 的缓存，以保证在蓝牙连接设备的时候，设备的服务、特征是最新的
     *
     * @param gatt
     * @return
     */
    public boolean refreshDeviceCache(BluetoothGatt gatt) {
        if (null != gatt) {
            try {
                BluetoothGatt localBluetoothGatt = gatt;
                Method localMethod = localBluetoothGatt.getClass().getMethod("refresh", new Class[0]);
                if (localMethod != null) {
                    boolean bool = ((Boolean) localMethod.invoke(
                            localBluetoothGatt, new Object[0])).booleanValue();
                    return bool;
                }
            } catch (Exception localException) {
                localException.printStackTrace();
            }
        }
        return false;
    }

    // BLE中心设备连接外围设备的数量有限(大概2~7个)，在建立新连接之前必须释放旧连接资源，否则容易出现连接错误133
    @SuppressLint("MissingPermission")
    private void closeConn() {
        if (mBluetoothGatt != null) {
            refreshDeviceCache(mBluetoothGatt);
            mBluetoothGatt.disconnect();
            mBluetoothGatt.close();
        }
    }

    // 扫描BLE
    public void reScan() {
        if (mBleDevAdapter.isScanning) {
            BaseApplication.toast("正在扫描...", 0);
        } else {
            mBleDevAdapter.reScan();
        }
    }

    // 清除Log
    public void cleanLog() {
        mTips.setText("");
    }

    // 注意：连续频繁读写数据容易失败，读写操作间隔最好200ms以上，或等待上次回调完成后再进行下次读写操作！
    // 读取数据成功会回调->onCharacteristicChanged()
    @SuppressLint("MissingPermission")
    public void read() {
        BluetoothGattService service = getGattService(BleServerActivity.UUID_SERVICE);
        if (service != null) {
            //通过UUID获取可读的Characteristic
            BluetoothGattCharacteristic characteristic = service.getCharacteristic(BleServerActivity.UUID_CHAR_READ_NOTIFY);
            mBluetoothGatt.readCharacteristic(characteristic);
        }
    }

    // 注意：连续频繁读写数据容易失败，读写操作间隔最好200ms以上，或等待上次回调完成后再进行下次读写操作！
    // 写入数据成功会回调->onCharacteristicWrite()
    @SuppressLint("MissingPermission")
    public void write() {
        BluetoothGattService service = getGattService(BleServerActivity.UUID_SERVICE);
        if (service != null) {
            String text = mWriteET.getText().toString();
            //通过UUID获取可写的Characteristic
            BluetoothGattCharacteristic characteristic = getGattCharacteristic(service, BleServerActivity.UUID_CHAR_WRITE);
            Log.i(TAG, "write:" + characteristic);
            if (null != characteristic) {
                characteristic.setValue(text.getBytes()); //单次最多20个字节
                mBluetoothGatt.writeCharacteristic(characteristic);
                //mWriteET.setText("");
            }
        }
    }

    // 设置通知Characteristic变化会回调->onCharacteristicChanged()
    @SuppressLint("MissingPermission")
    public void setNotify() {
        BluetoothGattService service = getGattService(BleServerActivity.UUID_SERVICE);
        if (service != null) {
            // 设置Characteristic通知
            //通过UUID获取可通知的Characteristic
            BluetoothGattCharacteristic characteristic = getGattCharacteristic(service, BleServerActivity.UUID_CHAR_READ_NOTIFY);
            if (null != characteristic){
                mBluetoothGatt.setCharacteristicNotification(characteristic, true);
                // 向Characteristic的Descriptor属性写入通知开关，使蓝牙设备主动向手机发送数据
                BluetoothGattDescriptor descriptor = characteristic.getDescriptor(BleServerActivity.UUID_DESC_NOTITY);
                // descriptor.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);//和通知类似,但服务端不主动发数据,只指示客户端读取数据
                descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                mBluetoothGatt.writeDescriptor(descriptor);
            }
        }
    }

    @SuppressLint("MissingPermission")
    public void  writeCmd() {
        BluetoothGattService service = getGattService(BleServerActivity.UUID_SERVICE);
        if (service != null) {

            String text = "client write:Hi " + count;
            byte[] write_cmd = text.getBytes();
            //byte[] write_cmd = new byte[] {(byte)0x01,0x01, 0x01, 0x00,0x00,(byte)0x2D};
            //通过UUID获取可写的Characteristic
            BluetoothGattCharacteristic characteristic = getGattCharacteristic(service, BleServerActivity.UUID_CHAR_WRITE);
            if (null != characteristic) {
                characteristic.setValue(write_cmd); //单次最多20个字节
                mBluetoothGatt.writeCharacteristic(characteristic);
                count++;
            }
        }
    }

    public void writeLongCmd() {

        //String text = "AA010101010000";
        String text = "AA01010101000F0102030405060708090A0B0C0D0E0F";
        String crc = CRC8.calcCrc8Str(IntByteStringHexUtil.hexStrToByteArray(text));
        String message = text + crc;

        byte[] write_cmd = IntByteStringHexUtil.hexStrToByteArray(message);
        //byte[] write_cmd = new byte[] {(byte)0xaa,0x01,0x01,0x01,0x01,0x00,0x00,(byte)0x2D};

        // 1、定义通讯协议，如下(这里只是个举例，可以项目扩展)
        // 协议号(2个字节)    消息号(1个字节)  功能(1个字节) 子功能(1个字节) 数据长度(2个字节) Data(N个字节) CRC校验(1个字节)
        //  AA01                 01            01          01            0000                        2D

        // 消息号(1个字节) 功能(1个字节) 子功能(1个字节) 数据长度(2个字节) 数据内容(N个字节) CRC校验(1个字节)
        //   01            01           01            0000            --             2D

        //2、封装通用发送数据接口(拆包)
        //该接口根据会发送数据内容按最大字节数拆分(一般20字节)放入队列，拆分完后，依次从队列里取出发送

        //3、封装通用接收数据接口(组包)
        //该接口根据从接收的数据按协议里的定义解析数据长度判读是否完整包，不是的话把每条消息累加起来

        //4、解析完整的数据包，进行业务逻辑处理

        //5、协议还可以加密解密，需要注意的选算法参数的时候，加密后的长度最好跟原数据长度一致，这样不会影响拆包组包

        logTv("写入长指令(大于20字节):\n" + message);

        bleNotifyDeviceByQueue(false, write_cmd);
    }

    // 获取Gatt服务
    private BluetoothGattService getGattService(UUID uuid) {
        if (!isConnected) {
            BaseApplication.toast("没有连接", 0);
            return null;
        }
        BluetoothGattService service = mBluetoothGatt.getService(uuid);
        if (service == null)
            BaseApplication.toast("没有找到服务UUID=" + uuid, 0);
        return service;
    }

    private BluetoothGattCharacteristic getGattCharacteristic(BluetoothGattService service, UUID uuid) {
        BluetoothGattCharacteristic gattCharacteristic = null;
        List<BluetoothGattCharacteristic> synchronizedList = Collections.synchronizedList(service.getCharacteristics());
        for (int i = 0; i < synchronizedList.size(); i++) {
            if (uuid.equals(synchronizedList.get(i).getUuid())) {
                gattCharacteristic = synchronizedList.get(i);
                break;
            }
        }
        return gattCharacteristic;
    }

    // 输出日志
    private void logTv(final String msg) {
        if (isDestroyed())
            return;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                BaseApplication.toast(msg, 0);
                mTips.append(msg + "\n\n");
                scrollToBottom();
            }
        });
    }


    private void bleNotifyDeviceByQueue(boolean isNeedEncrypt, byte[] data) {

        Log.e(TAG, "bleNotifyAppByQueue isNeedEncrypt=" + isNeedEncrypt);

        boolean isNeedSend = true;
        if (queue.size() > 0) {
            isNeedSend = false;
        }

        int section = data.length / bleSize;
        int remain = data.length % bleSize;

        //Log.e(TAG, "queue.size=" + queue.size() + ",data.length=" + data.length + ",section=" + section + ",remain=" + remain);

        if (section > 1 || (section == 1 && remain > 0)) {
            for (int i = 0; i < section; i++) {
                byte b_data[] = new byte[bleSize];
                System.arraycopy(data, i * bleSize, b_data, 0, bleSize);

                queue.add(Base64.encodeToString(b_data, Base64.NO_WRAP));
            }

            if (remain > 0) {
                byte b_data[] = new byte[remain];
                System.arraycopy(data, section * bleSize, b_data, 0, remain);

                queue.add(Base64.encodeToString(b_data, Base64.NO_WRAP));
            }
        } else {
            byte b_data[] = new byte[data.length];
            System.arraycopy(data, 0, b_data, 0, data.length);

            queue.add(Base64.encodeToString(b_data, Base64.NO_WRAP));
        }

        if (isNeedSend) {
            bleNotifyDevice(Base64.decode(queue.poll(), Base64.NO_WRAP));
        }
    }

    @SuppressLint("MissingPermission")
    private void bleNotifyDevice(byte[] data) {
        BluetoothGattService service = getGattService(BleServerActivity.UUID_SERVICE);
        if (service != null) {
            //通过UUID获取可写的Characteristic
            BluetoothGattCharacteristic characteristic = getGattCharacteristic(service, BleServerActivity.UUID_CHAR_WRITE);
            if (null != characteristic) {
                characteristic.setValue(data); //单次最多20个字节
                mBluetoothGatt.writeCharacteristic(characteristic);
            }
        }
    }
}