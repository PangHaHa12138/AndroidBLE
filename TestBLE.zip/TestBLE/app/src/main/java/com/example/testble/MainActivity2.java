package com.example.testble;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothGattServerCallback;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelUuid;
import android.util.Log;
import android.widget.Toast;

import java.util.List;
import java.util.UUID;

public class MainActivity2 extends AppCompatActivity {

    private static final UUID UUID_SERVICE = UUID.fromString("0000fff0-0000-1000-8000-008");
    private static final UUID UUID_DESC_NOTITY = UUID.fromString("00002902-0000-1000-8000-00");
    private static final UUID UUID_CHAR_READ_NOTIFY = UUID.fromString("0000fff1-0000-1000-8000-008");
    private static final UUID UUID_CHAR_WRITE = UUID.fromString("0000fff2-0000-1000-8000-00");
    private static final int REQUEST_LOCATION_PERMISSION = 0x11;
    private BluetoothAdapter mBluetoothAdapter;
    private final static int REQUEST_ENABLE_BT = 2;
    private boolean isScanning;
    private static final Handler mHandler = new Handler();
    private BluetoothLeScanner bluetoothLeScanner;
    private BluetoothAdapter.LeScanCallback leScanCallback;
    private BluetoothDevice bluetoothDevice;
    private ScanCallback mScanCallback;
    private BluetoothGatt bluetoothGatt;
    private ScanRecord scanRecord;
    private BluetoothGattCallback bluetoothGattCallback;
    private List<BluetoothGattService> bluetoothGattServiceList;
    private BluetoothGattCharacteristic notifyCharacteristic;
    private BluetoothGattCharacteristic writeCharacteristic;
    private BluetoothGattService bluetoothGattService;
    private BluetoothGattDescriptor bluetoothGattDescriptor;
    private AdvertiseCallback mAdvertiseCallback;
    private BluetoothLeAdvertiser mBluetoothLeAdvertiser;
    private BluetoothGattServerCallback mBluetoothGattServerCallback;
    private BluetoothGattServer mBluetoothGattServer;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        // 检查是否已经授予定位权限
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // 如果未授权，请求权限
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSION);

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION_PERMISSION);
        }

        if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            // 支持BLE
            final BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            //mBluetoothAdapter = bluetoothManager.getAdapter();
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

            if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }

            bluetoothLeScanner = mBluetoothAdapter.getBluetoothLeScanner();

            // 扫描结果Callback
            mScanCallback = new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
                    bluetoothDevice = result.getDevice();   //获取BLE设备信息
                    scanRecord = result.getScanRecord(); //获取BLE广播数据
                    int rssi = result.getRssi(); //获取信号强度
                    long time = result.getTimestampNanos(); //获取扫描时间

                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        boolean isConnectable = result.isConnectable(); //可连接
                        int txPower = result.getTxPower(); //获取发射功率
                        int advertisingSid = result.getAdvertisingSid(); //获取SID
                        int dataStatus = result.getDataStatus(); //获取数据状态
                    }
                }
            };

            bluetoothLeScanner.startScan(mScanCallback);
            isScanning = true;
            mHandler.postDelayed(new Runnable() {
                @SuppressLint("MissingPermission")
                @Override
                public void run() {
                    bluetoothLeScanner.stopScan(mScanCallback); //停止扫描
                    isScanning = false;
                }
            }, 3000);


            // 旧API是BluetoothAdapter.startLeScan(LeScanCallback callback)方式扫描BLE蓝牙设备，如下：

            leScanCallback = new BluetoothAdapter.LeScanCallback() {
                @SuppressLint("MissingPermission")
                @Override
                public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
                    // 处理扫描结果 device：找到的BLE设备 rssi：信号强度 scanRecord：广告数据
                    //device为扫描到的BLE设备
                    if (device.getName() == "目标设备名称") {
                        //获取目标设备
                        bluetoothDevice = device;
                    }
                    mBluetoothAdapter.stopLeScan(leScanCallback);
                }
            };
            mBluetoothAdapter.startLeScan(leScanCallback);
            //UUID[] uuid = new UUID[]{UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb")};
            //mBluetoothAdapter.startLeScan(uuid,leScanCallback);

            bluetoothGattCallback = new BluetoothGattCallback() {
                @Override
                public void onPhyUpdate(BluetoothGatt gatt, int txPhy, int rxPhy, int status) {
                    super.onPhyUpdate(gatt, txPhy, rxPhy, status);

                }

                @Override
                public void onPhyRead(BluetoothGatt gatt, int txPhy, int rxPhy, int status) {
                    super.onPhyRead(gatt, txPhy, rxPhy, status);
                }
                @SuppressLint("MissingPermission")
                @Override
                public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
                    super.onConnectionStateChange(gatt, status, newState);
                    //连接状态改变
                    if (newState == BluetoothGatt.STATE_CONNECTED) {

                        // 连接成功后，开始扫描服务
                        bluetoothGatt.discoverServices();
                    }
                    if (newState == BluetoothGatt.STATE_DISCONNECTED) {
                        // 连接断开
                        /*连接断开后的相应处理*/
                    }
                }

                @Override
                public void onServicesDiscovered(BluetoothGatt gatt, int status) {
                    super.onServicesDiscovered(gatt, status);
                    //服务发现成功的Callback

                    //获取服务列表
                    bluetoothGattServiceList = bluetoothGatt.getServices();

                }

                @Override
                public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
                    super.onCharacteristicRead(gatt, characteristic, status);

                    //读取Characteristic
                }

                @Override
                public void onCharacteristicRead(@NonNull BluetoothGatt gatt, @NonNull BluetoothGattCharacteristic characteristic, @NonNull byte[] value, int status) {
                    super.onCharacteristicRead(gatt, characteristic, value, status);

                }

                @Override
                public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
                    super.onCharacteristicWrite(gatt, characteristic, status);
                    //写入Characteristic
                    if (status == BluetoothGatt.GATT_SUCCESS) {
                        //写入成功

                    }
                }

                @Override
                public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
                    super.onCharacteristicChanged(gatt, characteristic);
                    //通知Characteristic

                    // value为设备发送的数据，根据数据协议进行解析
                    byte[] value = characteristic.getValue();
                }

                @Override
                public void onCharacteristicChanged(@NonNull BluetoothGatt gatt, @NonNull BluetoothGattCharacteristic characteristic, @NonNull byte[] value) {
                    super.onCharacteristicChanged(gatt, characteristic, value);
                }

                @Override
                public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
                    super.onDescriptorRead(gatt, descriptor, status);
                }

                @Override
                public void onDescriptorRead(@NonNull BluetoothGatt gatt, @NonNull BluetoothGattDescriptor descriptor, int status, @NonNull byte[] value) {
                    super.onDescriptorRead(gatt, descriptor, status, value);
                }
                @SuppressLint("MissingPermission")
                @Override
                public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
                    super.onDescriptorWrite(gatt, descriptor, status);
                    //若开启监听成功则会回调BluetoothGattCallback中的onDescriptorWrite()方法，处理方式如下:
                    if (status == BluetoothGatt.GATT_SUCCESS) {
                        //开启监听成功，可以向设备写入命令了
                        //value为客户端向服务端发送的指令
                        byte[] value = new byte[]{0x11};
                        writeCharacteristic.setValue(value);
                        bluetoothGatt.writeCharacteristic(writeCharacteristic);
                    }
                }

                @Override
                public void onReliableWriteCompleted(BluetoothGatt gatt, int status) {
                    super.onReliableWriteCompleted(gatt, status);
                }

                @Override
                public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
                    super.onReadRemoteRssi(gatt, rssi, status);
                }

                @Override
                public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
                    super.onMtuChanged(gatt, mtu, status);
                }

                @Override
                public void onServiceChanged(@NonNull BluetoothGatt gatt) {
                    super.onServiceChanged(gatt);
                }
            };
            //返回值 BluetoothGatt: BLE蓝牙连接管理类，主要负责与设备进行通信；
            //boolean autoConnect：建议置为false，能够提升连接速度；
            //BluetoothGattCallback callback 连接回调，重要参数，BLE通信的核心部分；
            bluetoothGatt = bluetoothDevice.connectGatt(this, false, bluetoothGattCallback);

            bluetoothGattService = bluetoothGatt.getService(UUID.fromString("蓝牙模块提供的负责通信服务UUID字符串"));
            // 例如形式如：49535343-fe7d-4ae5-8fa9-9fafd205e455
            notifyCharacteristic = bluetoothGattService.getCharacteristic(UUID.fromString("notify uuid"));
            writeCharacteristic = bluetoothGattService.getCharacteristic(UUID.fromString("write uuid"));


            bluetoothGatt.setCharacteristicNotification(notifyCharacteristic, true);
            bluetoothGattDescriptor = notifyCharacteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
            bluetoothGattDescriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);


            bluetoothGatt.disconnect();
            bluetoothGatt.close();


            //广播设置(必须)
            AdvertiseSettings settings = new AdvertiseSettings.Builder()
                    .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY) //广播模式: 低功耗,平衡,低延迟
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH) //发射功率级别: 极低,低,中,高
                    .setTimeout(0)
                    .setConnectable(true) //能否连接,广播分为可连接广播和不可连接广播
                    .build();

            //广播数据(必须，广播启动就会发送)
            AdvertiseData advertiseData = new AdvertiseData.Builder()
                    .setIncludeDeviceName(true) //包含蓝牙名称
                    .setIncludeTxPowerLevel(true) //包含发射功率级别
                    .addManufacturerData(1, new byte[]{23, 33}) //设备厂商数据，自定义
                    .build();

            //扫描响应数据(可选，当客户端扫描时才发送)
            AdvertiseData scanResponse = new AdvertiseData.Builder()
                    .addManufacturerData(2, new byte[]{66, 66}) //设备厂商数据，自定义
                    .addServiceUuid(new ParcelUuid(UUID_SERVICE)) //服务UUID
                    //.addServiceData(new ParcelUuid(UUID_SERVICE), new byte[]{2}) //服务数据，自定义
                    .build();


            // ============启动BLE蓝牙广播(广告) ===============
            mBluetoothLeAdvertiser = mBluetoothAdapter.getBluetoothLeAdvertiser();
            mBluetoothLeAdvertiser.startAdvertising(settings, advertiseData, scanResponse, mAdvertiseCallback);

            // BLE广播Callback
            mAdvertiseCallback = new AdvertiseCallback() {
                @Override
                public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                    Log.d("bluetoothBLE", "BLE广播开启成功");
                }

                @Override
                public void onStartFailure(int errorCode) {
                    Log.d("bluetoothBLE", "BLE广播开启失败,错误码:" + errorCode);
                }
            };

            // 注意：必须要开启可连接的BLE广播，其它设备才能发现并连接BLE服务端!
            // =============启动BLE蓝牙服务端======================================
            BluetoothGattService service = new BluetoothGattService(UUID_SERVICE, BluetoothGattService.SERVICE_TYPE_PRIMARY);

            //添加可读+通知characteristic
            BluetoothGattCharacteristic characteristicRead = new BluetoothGattCharacteristic(UUID_CHAR_READ_NOTIFY, BluetoothGattCharacteristic.PROPERTY_READ | BluetoothGattCharacteristic.PROPERTY_NOTIFY, BluetoothGattCharacteristic.PERMISSION_READ);
            characteristicRead.addDescriptor(new BluetoothGattDescriptor(UUID_DESC_NOTITY, BluetoothGattCharacteristic.PERMISSION_WRITE));
            service.addCharacteristic(characteristicRead);

            //添加可写characteristic
            BluetoothGattCharacteristic characteristicWrite = new BluetoothGattCharacteristic(UUID_CHAR_WRITE, BluetoothGattCharacteristic.PROPERTY_WRITE, BluetoothGattCharacteristic.PERMISSION_WRITE);
            service.addCharacteristic(characteristicWrite);

            mBluetoothGattServerCallback = new BluetoothGattServerCallback() {
                @Override
                public void onConnectionStateChange(BluetoothDevice device, int status, int newState) {
                    super.onConnectionStateChange(device, status, newState);
                    //1.状态发生改变
                }

                @Override
                public void onServiceAdded(int status, BluetoothGattService service) {
                    super.onServiceAdded(status, service);
                }
                @SuppressLint("MissingPermission")
                @Override
                public void onCharacteristicReadRequest(BluetoothDevice device, int requestId, int offset, BluetoothGattCharacteristic characteristic) {
                    super.onCharacteristicReadRequest(device, requestId, offset, characteristic);
                    mBluetoothGattServer.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, characteristic.getValue());

                }

                //3. onCharacteristicWriteRequest,接收具体的字节
                @SuppressLint("MissingPermission")
                @Override
                public void onCharacteristicWriteRequest(BluetoothDevice device, int requestId, BluetoothGattCharacteristic characteristic, boolean preparedWrite, boolean responseNeeded, int offset, byte[] value) {
                    super.onCharacteristicWriteRequest(device, requestId, characteristic, preparedWrite, responseNeeded, offset, value);

                    mBluetoothGattServer.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value);

                    //4.处理响应内容
                    onResponseToClient(value, device, requestId, characteristic);

                }

                //2.描述被写入时，在这里执行
                @SuppressLint("MissingPermission")
                @Override
                public void onDescriptorWriteRequest(BluetoothDevice device, int requestId, BluetoothGattDescriptor descriptor, boolean preparedWrite, boolean responseNeeded, int offset, byte[] value) {
                    super.onDescriptorWriteRequest(device, requestId, descriptor, preparedWrite, responseNeeded, offset, value);
                    // now tell the connected device that this was all successfull
                    mBluetoothGattServer.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value);

                }

                //5.特征被读取。当回复响应成功后，客户端会读取然后触发本方法
                @SuppressLint("MissingPermission")
                @Override
                public void onDescriptorReadRequest(BluetoothDevice device, int requestId, int offset, BluetoothGattDescriptor descriptor) {
                    super.onDescriptorReadRequest(device, requestId, offset, descriptor);
                    mBluetoothGattServer.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, null);
                }


                @Override
                public void onExecuteWrite(BluetoothDevice device, int requestId, boolean execute) {
                    super.onExecuteWrite(device, requestId, execute);
                }

                @Override
                public void onNotificationSent(BluetoothDevice device, int status) {
                    super.onNotificationSent(device, status);
                }

                @Override
                public void onMtuChanged(BluetoothDevice device, int mtu) {
                    super.onMtuChanged(device, mtu);
                }

                @Override
                public void onPhyUpdate(BluetoothDevice device, int txPhy, int rxPhy, int status) {
                    super.onPhyUpdate(device, txPhy, rxPhy, status);
                }

                @Override
                public void onPhyRead(BluetoothDevice device, int txPhy, int rxPhy, int status) {
                    super.onPhyRead(device, txPhy, rxPhy, status);
                }
            };
            mBluetoothGattServer = bluetoothManager.openGattServer(this, mBluetoothGattServerCallback);
            mBluetoothGattServer.addService(service);

        }
    }

    //4.处理响应内容
    @SuppressLint("MissingPermission")
    private void onResponseToClient(byte[] reqeustBytes, BluetoothDevice device, int requestId, BluetoothGattCharacteristic characteristic) {

        Log.e("bluetoothBLE", String.format("4.onResponseToClient：device name = %s, address = %s", device.getName(), device.getAddress()));
        Log.e("bluetoothBLE", String.format("4.onResponseToClient：requestId = %s", requestId));
        Log.e("bluetoothBLE", "4.收到：");

        String str = new String(reqeustBytes) + " hello>";
        characteristic.setValue(str.getBytes());
        mBluetoothGattServer.notifyCharacteristicChanged(device, characteristic, false);

        Log.i("bluetoothBLE", "4.响应：" + str);
        mHandler.obtainMessage(001, new String(reqeustBytes)).sendToTarget();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // 用户授权了定位权限，可以执行蓝牙扫描等操作
            } else {
                // 用户拒绝了定位权限，可能需要向用户解释为什么需要这个权限
            }
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                showToast("蓝牙已打开");
            } else if (resultCode == RESULT_CANCELED) {
                showToast("蓝牙未打开");
            }
        }
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}