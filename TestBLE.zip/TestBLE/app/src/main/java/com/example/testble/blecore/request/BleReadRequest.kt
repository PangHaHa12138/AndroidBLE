@file:Suppress("RemoveExplicitTypeArguments")

package com.example.testble.blecore.request

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import com.example.testble.blecore.callback.BleReadCallback
import com.example.testble.blecore.data.Constants.READ_TASK_ID
import com.example.testble.blecore.device.BleDevice
import com.example.testble.blecore.request.base.BleTaskQueueRequest
import com.example.testble.blecore.utils.BleLogger
import com.example.testble.blecore.utils.BleUtil
import com.example.testble.blecore.data.NoBlePermissionException
import com.example.testble.blecore.data.TimeoutCancelException
import com.example.testble.blecore.data.UnDefinedException
import com.example.testble.blecore.data.UnSupportException
import kotlinx.coroutines.TimeoutCancellationException
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine


/**
 * 设备读请求
 *
 * @author Buhuiming
 * @date 2023年06月07日 15时58分
 */
internal class BleReadRequest(
    private val bleDevice: BleDevice,
) : BleTaskQueueRequest(bleDevice, "Read队列") {

    private val bleReadCallbackHashMap:
            ConcurrentHashMap<String, BleReadCallback> = ConcurrentHashMap()

    @Synchronized
    private fun addReadCallback(uuid: String, bleReadCallback: BleReadCallback) {
        bleReadCallbackHashMap[uuid] = bleReadCallback
    }

    @Synchronized
    fun removeReadCallback(uuid: String?) {
        if (bleReadCallbackHashMap.containsKey(uuid)) {
            bleReadCallbackHashMap.remove(uuid)
        }
    }

    @Synchronized
    fun removeAllReadCallback() {
        bleReadCallbackHashMap.clear()
    }

    /**
     * read
     */
    @SuppressLint("MissingPermission")
    @Synchronized
    fun readCharacteristic(serviceUUID: String,
                           readUUID: String,
                           bleReadCallback: BleReadCallback
    ) {
        if (!BleUtil.isPermission(getBleManager().getContext())) {
            bleReadCallback.callReadFail(NoBlePermissionException())
            return
        }
        val characteristic = getCharacteristic(bleDevice, serviceUUID, readUUID)
        if (characteristic != null &&
            (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_READ) != 0
        ) {
            cancelReadJob(readUUID, getTaskId(readUUID))
            bleReadCallback.setKey(readUUID)
            addReadCallback(readUUID, bleReadCallback)
            var mContinuation: Continuation<Throwable?>? = null
            val task = getTask(
                getTaskId(readUUID),
                block = {
                    suspendCoroutine<Throwable?> { continuation ->
                        mContinuation = continuation
                        if (getBluetoothGatt(bleDevice)?.readCharacteristic(characteristic) == false) {
                            continuation.resume(UnDefinedException("Gatt读特征值数据失败"))
                        }
                    }
                },
                interrupt = { _, throwable ->
                    mContinuation?.resume(throwable)
                },
                callback = { _, throwable ->
                    throwable?.let {
                        BleLogger.e(it.message)
                        if (it is TimeoutCancellationException || it is TimeoutCancelException) {
                            val exception = TimeoutCancelException("$readUUID -> 读特征值数据失败，超时")
                            BleLogger.e(exception.message)
                            bleReadCallback.callReadFail(exception)
                        }
                    }
                }
            )
            getTaskQueue(readUUID)?.addTask(task)
        } else {
            val exception = UnSupportException("$readUUID -> 读特征值数据失败，此特性不支持读特征值数据")
            BleLogger.e(exception.message)
            bleReadCallback.callReadFail(exception)
        }
    }

    /**
     * 当读取设备数据时会触发
     */
    fun onCharacteristicRead(
        characteristic: BluetoothGattCharacteristic,
        value: ByteArray,
        status: Int
    ) {
        bleReadCallbackHashMap.values.forEach {
            if (characteristic.uuid?.toString().equals(it.getKey(), ignoreCase = true) &&
                cancelReadJob(it.getKey(), getTaskId(it.getKey()))) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    BleLogger.d(
                        "${it.getKey()} -> " +
                                "读特征值数据成功：${BleUtil.bytesToHex(value)}"
                    )
                    it.callReadSuccess(value)
                } else {
                    val exception = UnDefinedException(
                        "${it.getKey()} -> " +
                                "读特征值数据失败，status = $status"
                    )
                    BleLogger.e(exception.message)
                    it.callReadFail(exception)
                }
            }
        }
    }

    private fun getTaskId(uuid: String?) = READ_TASK_ID + uuid

    /**
     * 取消读特征值数据任务
     */
    @Synchronized
    private fun cancelReadJob(readUUID: String?, taskId: String): Boolean {
        return getTaskQueue(readUUID?: "")?.removeTask(taskId)?: false
    }

    override fun close() {
        super.close()
        removeAllReadCallback()
    }
}