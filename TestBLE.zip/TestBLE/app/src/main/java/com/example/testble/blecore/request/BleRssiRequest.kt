@file:Suppress("RemoveExplicitTypeArguments")

package com.example.testble.blecore.request

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import com.example.testble.blecore.callback.BleRssiCallback
import com.example.testble.blecore.control.BleTaskQueue
import com.example.testble.blecore.data.Constants.SET_RSSI_TASK_ID
import com.example.testble.blecore.data.NoBlePermissionException
import com.example.testble.blecore.data.TimeoutCancelException
import com.example.testble.blecore.data.UnDefinedException
import com.example.testble.blecore.device.BleDevice
import com.example.testble.blecore.request.base.Request
import com.example.testble.blecore.utils.BleLogger
import com.example.testble.blecore.utils.BleUtil
import kotlinx.coroutines.TimeoutCancellationException
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine


/**
 * 读取设备Rssi请求
 *
 * @author Buhuiming
 * @date 2023年06月07日 11时05分
 */
internal class BleRssiRequest(
    private val bleDevice: BleDevice,
) : Request() {

    private var bleRssiCallback: BleRssiCallback? = null

    private val bleTaskQueue: BleTaskQueue = BleTaskQueue("Rssi队列")

    @Synchronized
    private fun addRssiCallback(callback: BleRssiCallback) {
        bleRssiCallback = callback
    }

    @Synchronized
    fun removeRssiCallback() {
        bleRssiCallback = null
    }

    /**
     * 读取信号值
     */
    @SuppressLint("MissingPermission")
    @Synchronized
    fun readRemoteRssi(bleRssiCallback: BleRssiCallback) {
        if (!BleUtil.isPermission(getBleManager().getContext())) {
            bleRssiCallback.callRssiFail(NoBlePermissionException())
            return
        }
        cancelReadRssiJob()
        addRssiCallback(bleRssiCallback)
        var mContinuation: Continuation<Throwable?>? = null
        val task = getTask(
            getTaskId(),
            block = {
                suspendCoroutine<Throwable?> { continuation ->
                    mContinuation = continuation
                    if (getBluetoothGatt(bleDevice)?.readRemoteRssi() == false) {
                        continuation.resume(UnDefinedException("Gatt读取Rssi失败"))
                    }
                }
            },
            interrupt = { _, throwable ->
                mContinuation?.resume(throwable)
            },
            callback = { _, throwable ->
                throwable?.let {
                    BleLogger.e(it.message)
                    if (it is TimeoutCancellationException || it is TimeoutCancelException) {
                        BleLogger.e("${bleDevice.deviceAddress} -> 读取Rssi超时")
                        bleRssiCallback.callRssiFail(
                            TimeoutCancelException("${bleDevice.deviceAddress}" +
                                    " -> 读取Rssi失败，超时")
                        )
                    }
                }
            }
        )
        bleTaskQueue.addTask(task)
    }

    /**
     * 读取信号值后会触发
     */
    fun onReadRemoteRssi(rssi: Int, status: Int) {
        bleRssiCallback?.let {
            if (cancelReadRssiJob()) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    BleLogger.d("${bleDevice.deviceAddress} -> 读取Rssi成功：$rssi")
                    it.callRssiSuccess(rssi)
                } else {
                    val exception = UnDefinedException(
                        "${bleDevice.deviceAddress} -> " +
                                "读取Rssi失败，status = $status"
                    )
                    BleLogger.e(exception.message)
                    it.callRssiFail(exception)
                }
            }
        }
    }

    private fun getTaskId() = SET_RSSI_TASK_ID + bleDevice.deviceAddress

    /**
     * 取消读取Rssi任务
     */
    @Synchronized
    private fun cancelReadRssiJob(): Boolean {
        return bleTaskQueue.removeTask(getTaskId())
    }

    fun close() {
        bleTaskQueue.clear()
    }
}