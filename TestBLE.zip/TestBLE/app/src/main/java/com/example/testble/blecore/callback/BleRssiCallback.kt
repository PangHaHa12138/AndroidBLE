package com.example.testble.blecore.callback

import com.example.testble.blecore.callback.BleBaseCallback


/**
 * Rssi信号值回调
 *
 * @author Buhuiming
 * @date 2023年05月26日 15时54分
 */
open class BleRssiCallback : BleBaseCallback() {

    private var success: ((rssi: Int) -> Unit)? = null

    private var fail: ((throwable: Throwable) -> Unit)? = null

    fun onRssiFail(value: ((throwable: Throwable) -> Unit)) {
        fail = value
    }

    fun onRssiSuccess(value: ((rssi: Int) -> Unit)) {
        success = value
    }

    open fun callRssiFail(throwable: Throwable) {
        launchInMainThread {
            fail?.invoke(throwable)
        }
    }

    open fun callRssiSuccess(rssi: Int) {
        launchInMainThread {
            success?.invoke(rssi)
        }
    }
}