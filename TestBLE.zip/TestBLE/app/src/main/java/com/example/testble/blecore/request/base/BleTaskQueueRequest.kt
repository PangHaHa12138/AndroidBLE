package com.example.testble.blecore.request.base

import com.example.testble.blecore.control.BleTaskQueue
import com.example.testble.blecore.data.BleTaskQueueType
import com.example.testble.blecore.data.Constants.DEFAULT_TASK_QUEUE_TYPE
import com.example.testble.blecore.device.BleConnectedDeviceManager
import com.example.testble.blecore.device.BleDevice
import java.util.concurrent.ConcurrentHashMap


/**
 * 封装任务队列的Request
 *
 * @author Buhuiming
 * @date 2023年06月13日 16时03分
 */
internal open class BleTaskQueueRequest(
    private val bleDevice: BleDevice,
    private val tag: String
) : Request() {

    private var bleTaskQueueHashMap: ConcurrentHashMap<String, BleTaskQueue>? = null

    private val bleTaskQueueType = getBleOptions()?.taskQueueType?: DEFAULT_TASK_QUEUE_TYPE


    private var operateBleTaskQueue: BleTaskQueue? = null

    init {
        when (bleTaskQueueType) {
            BleTaskQueueType.Operate -> operateBleTaskQueue = BleTaskQueue(tag)
            BleTaskQueueType.Independent ->  bleTaskQueueHashMap = ConcurrentHashMap()
            else -> {}
        }
    }

    fun getTaskQueue(uuid: String): BleTaskQueue? {
        return when (bleTaskQueueType) {
            BleTaskQueueType.Default ->
                BleConnectedDeviceManager.get()
                    .getBleConnectedDevice(bleDevice)
                    ?.getShareBleTaskQueue()
            BleTaskQueueType.Operate -> operateBleTaskQueue
            BleTaskQueueType.Independent -> {
                if (bleTaskQueueHashMap?.containsKey(uuid) == true) {
                    bleTaskQueueHashMap?.get(uuid)
                } else {
                    val independentBleTaskQueue = BleTaskQueue(tag)
                    bleTaskQueueHashMap?.put(uuid, independentBleTaskQueue)
                    independentBleTaskQueue
                }
            }
        }
    }

    open fun close() {
        when (bleTaskQueueType) {
            BleTaskQueueType.Operate -> operateBleTaskQueue?.clear()
            BleTaskQueueType.Independent -> {
                bleTaskQueueHashMap?.forEach {
                    it.value.clear()
                }
                bleTaskQueueHashMap?.clear()
                bleTaskQueueHashMap = null
            }
            else -> {}
        }
    }
}