package com.example.testble.demo3.ble.characteristic;


import static com.example.testble.demo3.ble.main.BleProfile.W_COMMAND;

import com.example.testble.demo3.ble.enums.eBleCommand;
import com.example.testble.demo3.ble.main.BleCharacteristic;

public class BleCharcCommand extends BleCharacteristic {

    private eBleCommand mCommand;

    public BleCharcCommand(byte [] data){
        super(W_COMMAND, data);
        mCommand = eBleCommand.getCommand(data[0]);
    }

    @Override
    public byte[] serialize() {
        return new byte[]{mCommand.getCommand()};
    }

    public eBleCommand getCommand() {
        return mCommand;
    }
}
