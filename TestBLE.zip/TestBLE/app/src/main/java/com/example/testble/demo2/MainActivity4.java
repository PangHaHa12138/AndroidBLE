package com.example.testble.demo2;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.testble.R;
import com.example.testble.clientserver.BaseApplication;
import com.example.testble.clientserver.MainActivity3;

import java.util.ArrayList;
import java.util.List;

public class MainActivity4 extends AppCompatActivity implements OnClickListener  {

	private static final int REQUEST_CODE_OPEN_GPS = 2;
	private static final int REQUEST_PERMISSION_CODE = 3;
	private static final int REQUEST_ENABLE_BLUETOOTH = 4;
	private Button btnServer, btnClient;
	private static final String TAG = "BLE";

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo2);
        
        btnServer = (Button) findViewById(R.id.buttonServer);
        btnClient = (Button) findViewById(R.id.buttonClient);
        
        btnClient.setOnClickListener(this);
        btnServer.setOnClickListener(this);

		BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if (!bluetoothAdapter.isEnabled()) {
			// 蓝牙未打开
			Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
			startActivityForResult(enableBtIntent, REQUEST_ENABLE_BLUETOOTH);
			BaseApplication.toast("请先打开蓝牙", 0);
			return;
		}

		//如果未打开位置服务，让用户去打开
		if(!isLocationEnable(MainActivity4.this)){
			Intent locationIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
			startActivityForResult(locationIntent, REQUEST_CODE_OPEN_GPS);
			BaseApplication.toast("请先打开定位", 0);
		}

		List<String> mPermissionList = new ArrayList<>();
		// Android 版本大于等于 12 时，申请新的蓝牙权限
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
			mPermissionList.add(Manifest.permission.BLUETOOTH_SCAN);
			mPermissionList.add(Manifest.permission.BLUETOOTH_ADVERTISE);
			mPermissionList.add(Manifest.permission.BLUETOOTH_CONNECT);
			//根据实际需要申请定位权限
			mPermissionList.add(Manifest.permission.ACCESS_COARSE_LOCATION);
			mPermissionList.add(Manifest.permission.ACCESS_FINE_LOCATION);
		} else {
			mPermissionList.add(Manifest.permission.ACCESS_FINE_LOCATION);
			mPermissionList.add(Manifest.permission.ACCESS_COARSE_LOCATION);
		}
		boolean hasPermission = false;
		for (int i = 0; i < mPermissionList.size(); i++) {
			int permissionCheck = ContextCompat.checkSelfPermission(this, mPermissionList.get(i));
			hasPermission = permissionCheck == PackageManager.PERMISSION_GRANTED;
		}
		if (hasPermission) {

		} else {
			ActivityCompat.requestPermissions(this, mPermissionList.toArray(new String[0]), REQUEST_PERMISSION_CODE);
		}

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == REQUEST_CODE_OPEN_GPS) {

		} else if (requestCode == REQUEST_ENABLE_BLUETOOTH) {

		}
	}

	@Override
	public final void onRequestPermissionsResult(int requestCode,
												 @NonNull String[] permissions,
												 @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == REQUEST_PERMISSION_CODE) {
			if (grantResults.length > 0) {
				for (int i = 0; i < grantResults.length; i++) {
					if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {

					}
				}
			}
		}
	}

	private  boolean isLocationEnable(Context context) {
		LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
		boolean networkProvider = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
		boolean gpsProvider = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

		return networkProvider || gpsProvider;
	}

	@Override
	public void onClick(View v) {
		Intent intent;
		if (v.getId() == R.id.buttonServer){
			intent = new Intent(getApplicationContext(), ServerActivity.class);
			startActivity(intent);
		} else if (v.getId() == R.id.buttonClient) {
			intent = new Intent(getApplicationContext(), ClientActivity.class);
			startActivity(intent);
		}
	}
}
