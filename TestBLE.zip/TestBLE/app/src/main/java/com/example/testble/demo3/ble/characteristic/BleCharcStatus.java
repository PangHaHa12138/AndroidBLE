package com.example.testble.demo3.ble.characteristic;


import static com.example.testble.demo3.ble.main.BleProfile.R_STATUS;

import com.example.testble.demo3.ble.enums.eBleCommand;
import com.example.testble.demo3.ble.main.BleCharacteristic;

public class BleCharcStatus extends BleCharacteristic {

    private eBleCommand mCommand;
    private byte mStatus;

    public BleCharcStatus(eBleCommand command, byte status) {
        super(R_STATUS);
        mCommand = command;
        mStatus = status;
    }

    public BleCharcStatus(byte [] data) {
        super(R_STATUS);
        mCommand = eBleCommand.getCommand(data[0]);
        mStatus = data[1];
    }

    public eBleCommand getCommand(){
        return mCommand;
    }

    public byte getStatus(){
        return mStatus;
    }

    @Override
    public byte[] serialize(){
        return new byte[]{mCommand.getCommand(), mStatus};
    }
}
