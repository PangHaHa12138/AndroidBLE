@file:Suppress("SENSELESS_COMPARISON")

package com.example.testble.blecore.device

import com.example.testble.blecore.BleManager
import com.example.testble.blecore.control.BleLruHashMap
import com.example.testble.blecore.data.Constants.DEFAULT_MAX_CONNECT_NUM


/**
 * 连接设备BleConnectedDevice管理池
 *
 * @author Buhuiming
 * @date 2023年05月26日 08时54分
 */
internal class BleConnectedDeviceManager private constructor() {

    private val bleLruHashMap: BleLruHashMap =
        BleLruHashMap(
            BleManager.get().getOptions()?.maxConnectNum
            ?: DEFAULT_MAX_CONNECT_NUM)

    companion object {

        private var instance: BleConnectedDeviceManager = BleConnectedDeviceManager()

        @Synchronized
        fun get(): BleConnectedDeviceManager {
            if (instance == null) {
                instance = BleConnectedDeviceManager()
            }
            return instance
        }
    }

    /**
     * 添加设备控制器
     */
    fun buildBleConnectedDevice(bleDevice: BleDevice): BleConnectedDevice? {
        if (bleLruHashMap.containsKey(bleDevice.getKey())) {
            return bleLruHashMap[bleDevice.getKey()]
        }
        val bleConnectedDevice = BleConnectedDevice(bleDevice)
        bleLruHashMap[bleDevice.getKey()] = bleConnectedDevice
        return bleConnectedDevice
    }

    /**
     * 获取设备控制器
     */
    fun getBleConnectedDevice(bleDevice: BleDevice): BleConnectedDevice? {
        if (bleLruHashMap.containsKey(bleDevice.getKey())) {
            return bleLruHashMap[bleDevice.getKey()]
        }
        return null
    }

    /**
     * 移除设备控制器
     */
    @Synchronized
    fun removeBleConnectedDevice(key: String) {
        if (bleLruHashMap.containsKey(key)) {
            bleLruHashMap.remove(key)
        }
    }

    /**
     * 是否存在该设备
     */
    @Synchronized
    fun isContainDevice(bleDevice: BleDevice): Boolean {
        return bleLruHashMap.containsKey(bleDevice.getKey())
    }

    /**
     * 获取所有已连接设备集合
     */
    @Synchronized
    fun getAllConnectedDevice(): MutableList<BleDevice> {
        val list = mutableListOf<BleDevice>()
        bleLruHashMap.forEach {
            it.value?.let { device ->
                if (BleManager.get().isConnected(device.bleDevice)) {
                    list.add(device.bleDevice)
                }
            }
        }
        return list
    }

    /**
     * 断开某个设备的连接 释放资源
     */
    @Synchronized
    fun close(bleDevice: BleDevice) {
        getBleConnectedDevice(bleDevice)?.close()
        bleLruHashMap.remove(bleDevice.getKey())
    }

    /**
     * 断开所有设备的连接
     */
    @Synchronized
    fun disConnectAll() {
        bleLruHashMap.values.forEach {
            it?.disConnect()

        }
        closeAll()
    }

    /**
     * 断开所有连接 释放资源
     */
    @Synchronized
    fun closeAll() {
        bleLruHashMap.values.forEach {
            it?.close()
        }
        bleLruHashMap.clear()
    }
}