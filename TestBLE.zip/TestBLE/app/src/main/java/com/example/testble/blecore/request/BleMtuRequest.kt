@file:Suppress("RemoveExplicitTypeArguments")

package com.example.testble.blecore.request

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import com.example.testble.blecore.callback.BleMtuChangedCallback
import com.example.testble.blecore.control.BleTaskQueue
import com.example.testble.blecore.data.Constants.SET_MTU_TASK_ID
import com.example.testble.blecore.data.NoBlePermissionException
import com.example.testble.blecore.data.TimeoutCancelException
import com.example.testble.blecore.data.UnDefinedException
import com.example.testble.blecore.device.BleDevice
import com.example.testble.blecore.request.base.Request
import com.example.testble.blecore.utils.BleLogger
import com.example.testble.blecore.utils.BleUtil
import kotlinx.coroutines.TimeoutCancellationException
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine


/**
 * 设置Mtu请求
 *
 * @author Buhuiming
 * @date 2023年06月07日 15时25分
 */
internal class BleMtuRequest(private val bleDevice: BleDevice,
                             private val bleTaskQueue: BleTaskQueue
) : Request() {

    private var bleMtuChangedCallback: BleMtuChangedCallback? = null

    @Synchronized
    private fun addMtuChangedCallback(callback: BleMtuChangedCallback) {
        bleMtuChangedCallback = callback
    }

    @Synchronized
    fun removeMtuChangedCallback() {
        bleMtuChangedCallback = null
    }

    /**
     * 设置mtu
     */
    @SuppressLint("MissingPermission")
    @Synchronized
    fun setMtu(mtu: Int, bleMtuChangedCallback: BleMtuChangedCallback) {
        if (!BleUtil.isPermission(getBleManager().getContext())) {
            bleMtuChangedCallback.callSetMtuFail(NoBlePermissionException())
            return
        }
        cancelSetMtuJob()
        addMtuChangedCallback(bleMtuChangedCallback)
        var mContinuation: Continuation<Throwable?>? = null
        val task = getTask(
            getTaskId(),
            block = {
                suspendCoroutine<Throwable?> { continuation ->
                    mContinuation = continuation
                    if (getBluetoothGatt(bleDevice)?.requestMtu(mtu) == false) {
                        continuation.resume(UnDefinedException("Gatt设置mtu失败"))
                    }
                }
            },
            interrupt = { _, throwable ->
                mContinuation?.resume(throwable)
            },
            callback = { _, throwable ->
                throwable?.let {
                    BleLogger.e(it.message)
                    if (it is TimeoutCancellationException || it is TimeoutCancelException) {
                        val exception = TimeoutCancelException("${bleDevice.deviceAddress} -> 设置Mtu超时")
                        BleLogger.e(exception.message)
                        bleMtuChangedCallback.callSetMtuFail(exception)
                    }
                }
            }
        )
        bleTaskQueue.addTask(task)
    }

    /**
     * 设置Mtu值后会触发
     */
    fun onMtuChanged(mtu: Int, status: Int) {
        bleMtuChangedCallback?.let {
            if (cancelSetMtuJob()) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    BleLogger.d("${bleDevice.deviceAddress} -> 设置Mtu成功：$mtu")
                    it.callMtuChanged(mtu)
                    getBleOptions()?.mtu = mtu
                } else {
                    val exception = UnDefinedException(
                        "${bleDevice.deviceAddress} -> " +
                                "设置Mtu失败，status = $status"
                    )
                    BleLogger.e(exception.message)
                    it.callSetMtuFail(exception)
                }
            }
        }
    }

    private fun getTaskId() = SET_MTU_TASK_ID + bleDevice.deviceAddress

    /**
     * 取消设置Mtu任务
     */
    @Synchronized
    private fun cancelSetMtuJob(): Boolean {
        return bleTaskQueue.removeTask(getTaskId())
    }
}