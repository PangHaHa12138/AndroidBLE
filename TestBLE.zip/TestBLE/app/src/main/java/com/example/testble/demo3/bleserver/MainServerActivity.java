package com.example.testble.demo3.bleserver;

import static com.example.testble.demo3.ble.main.Utils.bleStateToString;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import com.example.testble.R;
import com.example.testble.demo3.ble.characteristic.BleCharcAuthor;
import com.example.testble.demo3.ble.characteristic.BleCharcBandwidth;
import com.example.testble.demo3.ble.characteristic.BleCharcCommand;
import com.example.testble.demo3.ble.characteristic.BleCharcStatus;
import com.example.testble.demo3.ble.enums.eBleCommand;
import com.example.testble.demo3.ble.enums.eBleStatus;
import com.example.testble.demo3.ble.main.BleOperation;
import com.example.testble.demo3.ble.main.BleProfile;
import com.example.testble.demo3.ble.main.IBleEvents;
import com.example.testble.demo3.ble.main.BleCharacteristic;



public class MainServerActivity extends AppCompatActivity implements IBleEvents {

    private static final int REQUEST_CODE_OPEN_GPS = 2;
    private static final int REQUEST_PERMISSION_CODE = 3;
    private static final int REQUEST_ENABLE_BLUETOOTH = 4;
    private final String TAG = Class.class.getSimpleName();

    private final int ONE_SECOND_MS = 1000;
    private final int ONE_MIN_MS = ONE_SECOND_MS * 60;
    private final int LOCATION_PERMISSION = 66;

    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;

    private BleServer mBleServer;
    private BleCharcBandwidth mBandwidthCharc;
    private ExecutorService mMsgExecutor;

    private final String mBandwidthTimerLock = "TimerLock";
    private Timer mBandwidthTimer;
    private AtomicBoolean mStarted;


    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server_main);

        mStarted = new AtomicBoolean(false);
        mMsgExecutor = Executors.newSingleThreadExecutor();

        mBluetoothManager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        mBluetoothAdapter = mBluetoothManager.getAdapter();

        // We can't continue without proper Bluetooth support
        if (!bluetoothSupported()) {
            finish();
        }
        else{
            if (!mBluetoothAdapter.isEnabled()) {
                showToast("Enabling Bluetooth");
                Log.d(TAG, "Enabling Bluetooth");
                //mBluetoothAdapter.enable();
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BLUETOOTH);
            }
        }

        requestLocationPermission();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        term();
    }

    private boolean bluetoothSupported() {
        if (mBluetoothAdapter == null) {
            showToast("Bluetooth not supported");
            Log.w(TAG, "Bluetooth not supported");
            return false;
        }

        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            showToast("Bluetooth LE not supported");
            Log.w(TAG, "Bluetooth LE not supported");
            return false;
        }

        return true;
    }

    private void requestLocationPermission(){
        List<String> mPermissionList = new ArrayList<>();
        // Android 版本大于等于 12 时，申请新的蓝牙权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            mPermissionList.add(Manifest.permission.BLUETOOTH_SCAN);
            mPermissionList.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            mPermissionList.add(Manifest.permission.BLUETOOTH_CONNECT);
            //根据实际需要申请定位权限
            mPermissionList.add(Manifest.permission.ACCESS_COARSE_LOCATION);
            mPermissionList.add(Manifest.permission.ACCESS_FINE_LOCATION);
        } else {
            mPermissionList.add(Manifest.permission.ACCESS_FINE_LOCATION);
            mPermissionList.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        boolean hasPermission = false;
        for (int i = 0; i < mPermissionList.size(); i++) {
            int permissionCheck = ContextCompat.checkSelfPermission(this, mPermissionList.get(i));
            hasPermission = permissionCheck == PackageManager.PERMISSION_GRANTED;
        }
        if (hasPermission) {
            init();
        } else {
            ActivityCompat.requestPermissions(this, mPermissionList.toArray(new String[0]), REQUEST_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == REQUEST_PERMISSION_CODE){
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                init();
            }
            else {
                requestLocationPermission();
            }
        }
    }

    private void init(){
        mBleServer = new BleServer(getApplicationContext());
        mBleServer.addBleMessageListener(this);

        mBleServer.init();

        runOnUiThread(() -> {
            TextView serverState = findViewById(R.id.txtServerState);
            serverState.setText("Server Started");
        });
    }

    private void showToast(String txt){
        runOnUiThread(() -> Toast.makeText(getApplicationContext(), txt, Toast.LENGTH_LONG).show());
    }

    private void send(BleCharacteristic charc){
        mMsgExecutor.execute(()->mBleServer.sendMessage(charc));
    }

    @Override
    public void bleConnectionStateChanged(int state) {
        String stateStr = bleStateToString(state);
        Log.d(TAG, "bleConnectionStateChanged. state=" + stateStr);

        if(state == BluetoothAdapter.STATE_DISCONNECTED){
            mStarted.set(false);
            synchronized (mBandwidthTimerLock){
                if(mBandwidthTimer != null){
                    mBandwidthTimer.cancel();
                    mBandwidthTimer = null;
                }
            }
        }

        runOnUiThread(() -> {
            TextView tv = findViewById(R.id.txtState);
            tv.setText(stateStr);
        });
    }

    @Override
    public void bleDataSent(BleOperation operation) {
        if(mStarted.get()){
            send(mBandwidthCharc);
        }
    }

    @Override
    public void bleDataReceived(UUID uuid, byte[] data) {
        long tId = Thread.currentThread().getId();
        if (BleProfile.W_COMMAND.equals(uuid)){
            BleCharcCommand commandCharacteristic = new BleCharcCommand(data);
            switch (commandCharacteristic.getCommand()) {
                case eCuBleCommand_Start:
                    Log.d(TAG, "Thread: " + tId + ". bleDataReceived. Start");
                    start();
                    break;
                case eCuBleCommand_Stop:
                    Log.d(TAG, "Thread: " + tId + ". bleDataReceived. Stop");
                    stop();
                    break;
                case eCuBleCommand_Get:
                    Log.d(TAG, "bleDataReceived. Get");
                    sendUser();
                    break;
                default:
                    Log.e(TAG, "bleDataReceived. Unknown command");
                    break;
            }
        }
    }

    private void sendUser(){
        send(new BleCharcAuthor(1, "Liron Komfort", "SW Engineer"));
    }

    private void start(){
        long tId = Thread.currentThread().getId();
        if (mBandwidthTimer == null){
            Log.d(TAG, "Thread: " + tId + ". start");
            mBandwidthCharc = new BleCharcBandwidth(mBleServer.getMtu());
            send(new BleCharcStatus(eBleCommand.eCuBleCommand_Start, eBleStatus.eBleStatus_Ok.getStatus()));
            mStarted.set(true);
            send(mBandwidthCharc);
            startBandwidthTimer();
        }
        else{
            byte errMask =  (byte)(eBleStatus.eBleStatus_Error.getStatus() | eBleStatus.eBleStatus_WrongState.getStatus());
            send(new BleCharcStatus(eBleCommand.eCuBleCommand_Start, errMask));
        }
    }

    private void stop(){
        long tId = Thread.currentThread().getId();
        Log.d(TAG, "Thread: " + tId + ". stop");
        cancelBandwidthTimer();
    }

    private void startBandwidthTimer(){
        synchronized (mBandwidthTimerLock){
            long tId = Thread.currentThread().getId();
            Log.d(TAG, "Thread: " + tId + ". startBandwidthTimer");
            mBandwidthTimer = new Timer();
            mBandwidthTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    long tId = Thread.currentThread().getId();
                    Log.d(TAG, "Thread: " + tId + ". BandwidthTimer expired");
                    cancelBandwidthTimer();
                }
            }, ONE_MIN_MS);
        }
    }

    private void cancelBandwidthTimer(){
        synchronized (mBandwidthTimerLock){
            long tId = Thread.currentThread().getId();
            Log.d(TAG, "Thread: " + tId + ". cancelBandwidthTimer");
            if(mBandwidthTimer != null){
                mStarted.set(false);
                mBandwidthTimer.cancel();
                mBandwidthTimer = null;
                send(new BleCharcStatus(eBleCommand.eCuBleCommand_Stop, eBleStatus.eBleStatus_Ok.getStatus()));
            }
        }
    }

    private void term(){
        if(mBandwidthTimer != null){
            mBandwidthTimer.cancel();
            mBandwidthTimer = null;
        }

        if(mMsgExecutor != null){
            mMsgExecutor.shutdown();
            mMsgExecutor = null;
        }

        mBleServer.clearListenersList();
        mBleServer.term();
    }
}