package com.example.testble.blecore.data


/**
 * 连接的最后状态
 *
 * @author Buhuiming
 * @date 2023年05月29日 09时02分
 */
internal sealed class BleConnectLastState {

    /**
     * 初始状态
     */
    object ConnectIdle : BleConnectLastState()

    /**
     * 连接中状态
     */
    object Connecting : BleConnectLastState()

    /**
     * 已连接状态
     */
    object Connected : BleConnectLastState()

    /**
     * 连接失败状态
     */
    object ConnectFailure : BleConnectLastState()

    /**
     * 断开状态
     */
    object Disconnect : BleConnectLastState()
}