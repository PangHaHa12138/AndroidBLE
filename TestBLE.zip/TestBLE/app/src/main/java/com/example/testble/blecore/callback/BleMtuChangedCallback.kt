package com.example.testble.blecore.callback

import com.example.testble.blecore.callback.BleBaseCallback


/**
 * mtu值变化回调
 *
 * @author Buhuiming
 * @date 2023年05月26日 16时17分
 */
open class BleMtuChangedCallback : BleBaseCallback() {

    private var mtuChanged: ((mtu: Int) -> Unit)? = null

    private var fail: ((throwable: Throwable) -> Unit)? = null

    fun onSetMtuFail(value: ((throwable: Throwable) -> Unit)) {
        fail = value
    }

    fun onMtuChanged(value: ((mtu: Int) -> Unit)) {
        mtuChanged = value
    }

    open fun callSetMtuFail(throwable: Throwable) {
        launchInMainThread {
            fail?.invoke(throwable)
        }
    }

    open fun callMtuChanged(mtu: Int) {
        launchInMainThread {
            mtuChanged?.invoke(mtu)
        }
    }
}