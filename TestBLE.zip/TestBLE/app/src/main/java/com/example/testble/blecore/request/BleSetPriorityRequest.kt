package com.example.testble.blecore.request

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import com.example.testble.blecore.device.BleDevice
import com.example.testble.blecore.request.base.Request
import com.example.testble.blecore.utils.BleLogger
import com.example.testble.blecore.utils.BleUtil


/**
 * 设置设备的传输优先级请求
 *
 * @author Buhuiming
 * @date 2023年06月07日 15时45分
 */
internal class BleSetPriorityRequest(private val bleDevice: BleDevice) : Request() {

    /**
     * 设置设备的传输优先级
     * connectionPriority 必须是 [BluetoothGatt.CONNECTION_PRIORITY_BALANCED]、
     * [BluetoothGatt.CONNECTION_PRIORITY_HIGH]、
     * [BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER]的其中一个
     *
     */
    @SuppressLint("MissingPermission")
    fun setConnectionPriority(connectionPriority: Int): Boolean {
        if (!BleUtil.isPermission(getBleManager().getContext())) {
            BleLogger.e("${bleDevice.deviceAddress} -> 设置设备的传输优先级失败，没有权限")
            return false
        }
        val result = getBluetoothGatt(bleDevice)?.requestConnectionPriority(connectionPriority)?: false
        if (result) {
            BleLogger.i("${bleDevice.deviceAddress} -> 设置设备的传输优先级成功")
        } else {
            BleLogger.e("${bleDevice.deviceAddress} -> 设置设备的传输优先级失败")
        }
        return result
    }
}