package com.example.testble.blecore.callback

import com.example.testble.blecore.callback.BleBaseCallback


/**
 * 读回调
 *
 * @author Buhuiming
 * @date 2023年05月26日 15时54分
 */
open class BleReadCallback : BleBaseCallback() {

    private var readSuccess: ((data: ByteArray) -> Unit)? = null

    private var readFail: ((throwable: Throwable) -> Unit)? = null

    fun onReadFail(value: ((throwable: Throwable) -> Unit)) {
        readFail = value
    }

    fun onReadSuccess(value: ((data: ByteArray) -> Unit)) {
        readSuccess = value
    }

    open fun callReadFail(throwable: Throwable) {
        launchInMainThread {
            readFail?.invoke(throwable)
        }
    }

    open fun callReadSuccess(data: ByteArray) {
        launchInMainThread {
            readSuccess?.invoke(data)
        }
    }
}