package com.example.testble.blecore.callback

import com.example.testble.blecore.callback.BleBaseCallback


/**
 * 订阅通知回调
 * Notify方式
 *
 * @author Buhuiming
 * @date 2023年05月29日 08时47分
 */
open class BleNotifyCallback : BleBaseCallback() {

    private var notifySuccess: (() -> Unit)? = null

    private var notifyFail: ((throwable: Throwable) -> Unit)? = null

    private var characteristicChanged: ((data: ByteArray) -> Unit)? = null

    fun onNotifyFail(value: ((throwable: Throwable) -> Unit)) {
        notifyFail = value
    }

    fun onNotifySuccess(value: (() -> Unit)) {
        notifySuccess = value
    }

    fun onCharacteristicChanged(value: ((data: ByteArray) -> Unit)) {
        characteristicChanged = value
    }

    open fun callNotifyFail(throwable: Throwable) {
        launchInMainThread {
            notifyFail?.invoke(throwable)
        }
    }

    open fun callNotifySuccess() {
        launchInMainThread {
            notifySuccess?.invoke()
        }
    }

    open fun callCharacteristicChanged(data: ByteArray) {
        //数据处理放在非主线程
        launchInIOThread {
            characteristicChanged?.invoke(data)
        }
    }
}