package com.example.hlkb40_demo;

import android.widget.ImageView;
import android.widget.TextView;

public class MyFile {
	public ImageView mFileImageView;  //文件图片
	public TextView mFileNameTV;    //文件�?
}
